'use strict';

module.exports = function(Apiparamhod) {

};
