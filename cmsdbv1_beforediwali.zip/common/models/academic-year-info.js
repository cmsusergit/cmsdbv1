'use strict';

module.exports = function(Academicyearinfo) {

};
