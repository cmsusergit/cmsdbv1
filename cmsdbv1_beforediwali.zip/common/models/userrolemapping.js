'use strict';

module.exports = function(Userrolemapping) {

};
