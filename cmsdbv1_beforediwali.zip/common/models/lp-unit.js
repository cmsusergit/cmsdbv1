'use strict';

module.exports = function(Lpunit) {

};
