'use strict';

module.exports = function(Loadcalcdept) {

};
