'use strict';

module.exports = function(Feescategory) {

};
