'use strict';

module.exports = function(Ttlocationinfo) {

};
