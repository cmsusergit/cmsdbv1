'use strict';

module.exports = function(Feescount) {

};
