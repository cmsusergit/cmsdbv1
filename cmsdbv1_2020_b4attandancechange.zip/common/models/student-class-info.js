'use strict';

module.exports = function(Studentclassinfo) {

};
