'use strict';

module.exports = function(Lptopic) {

};
