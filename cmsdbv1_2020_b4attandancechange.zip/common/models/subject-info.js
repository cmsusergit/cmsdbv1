'use strict';

module.exports = function(Subjectinfo) {

};
