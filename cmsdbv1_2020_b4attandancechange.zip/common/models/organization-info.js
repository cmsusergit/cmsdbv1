'use strict';

module.exports = function(Organizationinfo) {

};
