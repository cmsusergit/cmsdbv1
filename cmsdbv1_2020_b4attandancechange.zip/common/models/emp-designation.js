'use strict';

module.exports = function(Empdesignation) {

};
