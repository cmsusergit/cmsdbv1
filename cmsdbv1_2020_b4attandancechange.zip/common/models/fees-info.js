'use strict';

module.exports = function(Feesinfo) {

};
