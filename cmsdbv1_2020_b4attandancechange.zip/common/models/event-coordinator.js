'use strict';

module.exports = function(Eventcoordinator) {

};
