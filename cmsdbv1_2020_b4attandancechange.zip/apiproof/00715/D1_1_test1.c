#include<stdio.h>
#include<stdlib.h>

void sort(int[],int);
int main()
{
  int indx1,zoneCount[5];
  int tt,mergedList[500];
  int count,selectedCandidate[50];
  int indx,zoneCandidateList[5][50];
  int selectedCount=0;


  for(indx=0;indx<5;indx++)
    scanf("%d",&zoneCount[indx]);
  for(indx=0;indx<5;indx++){
    printf("Zone %d\n",(indx+1));
    for(indx1=0;indx1<zoneCount[indx];indx1++)
      scanf("%d",&zoneCandidateList[indx][indx1]);
  }
  printf("----\n");
  for(indx=0;indx<5;indx++){
    for(indx1=0;indx1<zoneCount[indx];indx1++)
      printf("%d ",zoneCandidateList[indx][indx1]);
    printf("\n");
  }
  count=0;
  for(indx=0;indx<5;indx++){
    for(indx1=0;indx1<zoneCount[indx];indx1++)
      mergedList[count++]=zoneCandidateList[indx][indx1];
  }
  sort(mergedList,count);
  for(indx=0;indx<count;indx++)
    printf("%d ",mergedList[indx]);
  tt=0;
  for(indx=0;indx<count-1;indx++){
    if(mergedList[indx]==mergedList[indx+1]){
      tt++;
    }
    else
    {
      printf("****%d\n",tt);
      if(tt>2){
            selectedCandidate[selectedCount++]=mergedList[indx];
      }
      tt=0;
    }
  }
  printf("Selected Candidate\n");
  for(indx=0;indx<selectedCount;indx++)
    printf("%d\n",selectedCandidate[indx]);
  return 0;
}
void sort(int xx[],int count){
  int temp;
  int indx,indx1;
  for(indx=0;indx<count;indx++){
    for(indx1=0;indx1<count-1;indx1++)
      if(xx[indx1]>xx[indx1+1])
      {
        temp=xx[indx1];
        xx[indx1]=xx[indx1+1];
        xx[indx1+1]=temp;
      }
  }

}
